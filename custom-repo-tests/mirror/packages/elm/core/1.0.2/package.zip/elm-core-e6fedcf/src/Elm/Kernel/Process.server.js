/*

import Elm.Kernel.Scheduler exposing (binding)

*/


function _Process_sleep()
{
	return __Scheduler_binding(function() {});
}
