# Virtual DOM for Elm

A virtual DOM implementation that backs Elm's core libraries for [HTML](https://package.elm-lang.org/packages/elm/html/latest/) and [SVG](https://package.elm-lang.org/packages/elm/svg/latest/). You should almost certainly use those higher-level libraries directly.

It is pretty fast! You can read about that [here](https://elm-lang.org/blog/blazing-fast-html-round-two).
